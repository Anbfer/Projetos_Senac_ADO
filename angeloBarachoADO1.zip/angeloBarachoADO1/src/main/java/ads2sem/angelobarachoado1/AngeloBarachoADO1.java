/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ads2sem.angelobarachoado1;

/**
 *
 * @author angelo.bferreira
 */
public class AngeloBarachoADO1 {

    public static void main(String[] args) {
        
    }
}
