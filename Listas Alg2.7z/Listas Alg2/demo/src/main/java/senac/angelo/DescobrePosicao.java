package senac.angelo;

public class DescobrePosicao {

    public static void main(String[] args) {
        int[] vetore = new int [8];
        
        ManipulaVetoresDeInteiros vetor = new ManipulaVetoresDeInteiros();
        vetor.setVetor(vetore);
        vetor.preencherVetorComInteiros(vetore);
        vetor.imprimeVetor(vetore);
        String maiorValor = vetor.maiorValorDoVetor(vetore);
        System.out.println(maiorValor);
    }
}
