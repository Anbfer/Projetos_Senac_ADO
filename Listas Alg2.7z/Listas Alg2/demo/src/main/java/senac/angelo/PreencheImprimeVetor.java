package senac.angelo;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class PreencheImprimeVetor {

    public static int pegaInputTecladoInteiro() {
        Scanner input = new Scanner(System.in);
        int entrada = input.nextInt();
        return entrada;
    }

    public static void imprimeVetorComoLista(int[] vetor) {
        for (int item : vetor) {
            System.out.printf(item + " ");
        }
    }

    public static int[] preencheVetor(int[] vetor) {
        for (int i = 0; i < vetor.length; i++) {
            System.out.println("Informe um numero inteiro para preencher o vetor: ");
            vetor[i] = pegaInputTecladoInteiro();
        }

        return vetor;
    }

    public static void main(String[] args) {

        int[] vetorDeInteiros = new int[10];

        vetorDeInteiros = preencheVetor(vetorDeInteiros);
        imprimeVetorComoLista(vetorDeInteiros);
    }

}
