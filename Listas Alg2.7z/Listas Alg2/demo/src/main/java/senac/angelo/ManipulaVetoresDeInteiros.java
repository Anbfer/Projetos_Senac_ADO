package senac.angelo;

import java.util.Scanner;

public class ManipulaVetoresDeInteiros {
    private int[] vetor;

    public ManipulaVetoresDeInteiros(){

    }

    public int[] getVetor() {
        return vetor;
    }

    public void setVetor(int [] vetor) {
        this.vetor = vetor;
    }

    public void imprimeVetor(int [] vetor){
        for (int item : vetor) {
            System.out.printf(item + " ");
        }
    }

    public int pegaEntradaDeInteiros() {
        Scanner input = new Scanner(System.in);
        int entrada = input.nextInt();

        return entrada;
    }

    public int[] preencherVetorComInteiros(int [] vetor) {
        for (int i = 0; i < vetor.length; i++) {
            System.out.println("Informe valores a preencher o vetor: ");
            vetor[i] = pegaEntradaDeInteiros();
        }
        
        return vetor;
    }

    public String maiorValorDoVetor(int [] vetor) {
        int maior = 0;
        int posicaoMaior = 0;

        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] > maior) {
                maior = vetor[i];
                posicaoMaior = i;
            }
        }
        String maiorValor = "\nO maior valor do vetor é: " + maior + "\nNa posição: " + posicaoMaior;

        return maiorValor;
    }
    
}
